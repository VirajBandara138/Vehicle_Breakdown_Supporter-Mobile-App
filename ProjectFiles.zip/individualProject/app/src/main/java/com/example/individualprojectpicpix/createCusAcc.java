package com.example.individualprojectpicpix;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class createCusAcc extends AppCompatActivity {

    private EditText customerNameEdt, customerContactEdt, customerEmailEdt, customerPasswordEdt;
    private Button addCustomerBtn;
    private DatabaseHelper1 dbHandler;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_cus_acc);

        // initializing all our variables.
        customerNameEdt = findViewById(R.id.txtname);
        customerContactEdt = findViewById(R.id.txtContact);
        customerEmailEdt = findViewById(R.id.txtEmail);
        customerPasswordEdt = findViewById(R.id.txtPassword);
        addCustomerBtn = findViewById(R.id.btnSignUp);

        // creating a new DBHandler instance
        // and passing our context to it.
        dbHandler = new DatabaseHelper1(createCusAcc.this);

        // adding onClickListener for add customer button.
        addCustomerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // getting data from all EditText fields.
                String customerName = customerNameEdt.getText().toString();
                String customerContact = customerContactEdt.getText().toString();
                String customerEmail = customerEmailEdt.getText().toString();
                String customerPassword = customerPasswordEdt.getText().toString();
                String name = "Name";
                String contact = "Contact";
                String password = "Password";
                String email = "Email";

                // validating if the fields are empty or not.
                if (customerName.isEmpty() || customerContact.isEmpty() || customerEmail.isEmpty() || customerPassword.isEmpty()) {
                    Toast.makeText(createCusAcc.this, "Please enter all the data..", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (customerName.equals(name) || customerContact.equals(contact) || customerEmail.equals(password) || customerPassword.equals(email)) {
                    Toast.makeText(createCusAcc.this, "Please enter all the data..", Toast.LENGTH_SHORT).show();
                    return;
                }

                // adding new customer to SQLite database.
                dbHandler.addNewCustomer(customerName, customerContact, customerEmail, customerPassword);

                // displaying a toast message after adding the customer.
                Toast.makeText(createCusAcc.this, "Customer has been added.", Toast.LENGTH_SHORT).show();

                // clearing all EditText fields after adding customer.
                customerNameEdt.setText("");
                customerContactEdt.setText("");
                customerEmailEdt.setText("");
                customerPasswordEdt.setText("");

                startActivity(new Intent(createCusAcc.this, loginCustomer.class));
            }



        });


    }

    public void reload(View view) {
        recreate();
    }

    public void loginButton(View view) {
        startActivity(new Intent(createCusAcc.this, loginCustomer.class));
    }
}