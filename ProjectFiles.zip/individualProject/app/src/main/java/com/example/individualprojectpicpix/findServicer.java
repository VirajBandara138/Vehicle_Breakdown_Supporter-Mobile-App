package com.example.individualprojectpicpix;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;


public class findServicer extends AppCompatActivity {

    private EditText vehicleNumber;
    private EditText vehicleModel;
    private EditText vehicleColor;
    private EditText breakdown;


    private DatabaseHelper1 dbHandler;

    private Button find;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_servicer);

        vehicleNumber = findViewById(R.id.txtVehicleNumber);
        vehicleModel = findViewById(R.id.txtVehicleModel);
        vehicleColor = findViewById(R.id.txtVehicleColor);
        breakdown = findViewById(R.id.txtBNDetails);

        find = findViewById(R.id.btnPickNext);


        dbHandler = new DatabaseHelper1(findServicer.this);


        find.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // getting data from all EditText fields.
                String vehicleNumbertxt = vehicleNumber.getText().toString();
                String vehicleModeltxt = vehicleModel.getText().toString();
                String vehicleColortxt = vehicleColor.getText().toString();
                String breakdowntxt = breakdown.getText().toString();

                String defaultVehicleNumber = "Vehicle Number";
                String defaultVehicleModel = "Vehicle Model";
                String defaultVehicleColor = "Vehicle Color";
                String defaultBreakdown = "Break Down Details";

                // checking if the user is not trying to submit an empty field.

                if (vehicleNumbertxt.isEmpty() || vehicleModeltxt.isEmpty() || vehicleColortxt.isEmpty() || breakdowntxt.isEmpty()) {
                    Toast.makeText(findServicer.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                // checking if the user is not trying to submit an incorrect data.

                if (vehicleNumbertxt.equals(defaultVehicleNumber) || vehicleModeltxt.equals(defaultVehicleModel) || vehicleColortxt.equals(defaultVehicleColor) || breakdowntxt.equals(defaultBreakdown)) {
                    Toast.makeText(findServicer.this, "Please enter correct data", Toast.LENGTH_SHORT).show();
                }

                // adding new entry to SQLite database.

                boolean inserted = dbHandler.addFindService(vehicleNumbertxt, vehicleModeltxt, vehicleColortxt, breakdowntxt);
                if (inserted) {
                    Toast.makeText(findServicer.this, "Data added successfully", Toast.LENGTH_SHORT).show();
                    vehicleNumber.setText("");
                    vehicleModel.setText("");
                    vehicleColor.setText("");
                    breakdown.setText("");
                    startActivity(new Intent(findServicer.this, getLocation.class));
                } else {
                    Toast.makeText(findServicer.this, "Failed to add data", Toast.LENGTH_SHORT).show();
                }
                // displaying a toast message after adding the entry.

                //

                // clearing all EditText fields after adding entry.

            }
        });
    }



    public void clear(View view) {
        vehicleNumber.setText("");
        vehicleModel.setText("");
        vehicleColor.setText("");
        breakdown.setText("");
    }


    public void backButton(View view) {
        startActivity(new Intent(findServicer.this, custHome.class));
    }


    public void reload(View view) {
        recreate();
    }
}

