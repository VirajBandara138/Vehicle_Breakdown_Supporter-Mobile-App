package com.example.individualprojectpicpix;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class viewCustomerDetails extends AppCompatActivity {

    private ListView listView;
    private DatabaseHelper1 dbHelper;
    private EditText emailEditText;
   private Button viewbtn;

    private Button deleteBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_customer_details);

        emailEditText = findViewById(R.id.emailEditText);
        listView = findViewById(R.id.listView);
        viewbtn = findViewById(R.id.btnview);
        deleteBtn = findViewById(R.id.btndelete);



        dbHelper = new DatabaseHelper1(this);

        viewbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailEditText.getText().toString().trim();
                if (!TextUtils.isEmpty(email)) {
                    ArrayList<String> list = dbHelper.getCustomerByEmail(email);
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(viewCustomerDetails.this, R.layout.list_item1, list);
                    listView.setAdapter(adapter);
                } else {
                    Toast.makeText(viewCustomerDetails.this, "Please enter an email", Toast.LENGTH_SHORT).show();
                }
            }
        });

        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailEditText.getText().toString().trim();
                if (!TextUtils.isEmpty(email)) {
                    dbHelper.deleteCustomerByEmail(email);
                    Toast.makeText(viewCustomerDetails.this, "Customer deleted successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(viewCustomerDetails.this, "Please enter an email", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }


    public void clear(View view) {
        emailEditText.setText("");
    }

    public void goHome(View view) {

    }

    public void goBack(View view) {
        startActivity(new Intent(viewCustomerDetails.this, addServicing.class));
    }

    public void viewLocation(View view) {
        startActivity(new Intent(viewCustomerDetails.this, customerLocation.class));
    }

    public void reload(View view) {
        recreate();
    }
}
