package com.example.individualprojectpicpix;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.ArrayList;

public class CustomerAdapter extends ArrayAdapter<String> {

    private ArrayList<String> customerList;

    public CustomerAdapter(Context context, ArrayList<String> customers) {
        super(context, 0, customers);
        this.customerList = customers;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        String customerData = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
        }

        TextView textViewCustomer = convertView.findViewById(R.id.textViewCustomer);
        textViewCustomer.setText(customerData);

        return convertView;
    }
}

