package com.example.individualprojectpicpix;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class cusFeedback extends AppCompatActivity {

   private Button btnaddfeedback;
    private EditText txtFeedBack;

    private DatabaseHelper1 db_handler;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cus_feedback);

        btnaddfeedback = findViewById(R.id.btnFeedback);
        txtFeedBack = findViewById(R.id.editMultiLine);

        db_handler = new DatabaseHelper1(cusFeedback.this);

        btnaddfeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String feedback = txtFeedBack.getText().toString();

                db_handler.addFeedBack(feedback);

                Toast.makeText(cusFeedback.this, "Entry has been added.", Toast.LENGTH_SHORT).show();
            }
        });

    }


    public void HomeButton(View view) {
        startActivity(new Intent(cusFeedback.this, welcome2.class));
    }

    public void reEnter(View view) {
        startActivity(new Intent(cusFeedback.this, cusFeedback.class));
    }

    public void exit(View view) {
        finish();
    }
}