package com.example.individualprojectpicpix;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class addServicing extends AppCompatActivity {
    private EditText vehicleNumber, vehicleModel,customerName,whatDid,charge;
    private Button btnAddService;

    private DatabaseHelper1 dbHandler;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_servicing);

        vehicleNumber = findViewById(R.id.txtVehicleNumber);
        vehicleModel = findViewById(R.id.txtVehicleModel);
        customerName = findViewById(R.id.txtCustomerName);
        whatDid = findViewById(R.id.txtWhatDid);
        charge = findViewById(R.id.txtCharge);
        btnAddService = findViewById(R.id.btnAddService);

        dbHandler = new DatabaseHelper1(addServicing.this);

        btnAddService.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // getting data from all EditText fields.
                String VehicleNameString = vehicleNumber.getText().toString();
                String VehicleModelString = vehicleModel.getText().toString();
                String CustomerNameString = customerName.getText().toString();
                String WhatDidString = whatDid.getText().toString();
                String ChargeString = charge.getText().toString();

                String check1 = "Vehicle Number";
                String check2 = "Vehicle Modal";
                String check3 = "Customer Name";
                String check4 = "txtWhatDid";
                String check5 = "Charge for Servicing";

                // validating if the fields are empty or not.
                if (VehicleNameString.isEmpty() || VehicleModelString.isEmpty() || CustomerNameString.isEmpty() || WhatDidString.isEmpty() || ChargeString.isEmpty() ) {
                    Toast.makeText(addServicing.this, "Please enter all the data..", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (VehicleNameString.equals(check1) || VehicleModelString.equals(check2) || CustomerNameString.equals(check3) || WhatDidString.equals(check4) || ChargeString.equals(check5) ) {
                    Toast.makeText(addServicing.this, "Please enter all the data..", Toast.LENGTH_SHORT).show();
                    return;
                }

                // adding new customer to SQLite database.
                dbHandler.addNewServicing(VehicleNameString,VehicleModelString,CustomerNameString,WhatDidString,ChargeString);

                // displaying a toast message after adding the customer.
                Toast.makeText(addServicing.this, "Customer has been added.", Toast.LENGTH_SHORT).show();

                // clearing all EditText fields after adding customer.
                vehicleNumber.setText("");
                vehicleModel.setText("");
                customerName.setText("");
                whatDid.setText("");
                charge.setText("");

                startActivity(new Intent(addServicing.this, employeeHome.class));
            }


        });
    }

    public void clear(View view) {
        vehicleNumber.setText("");
    }

    public void backButton(View view) {
        startActivity(new Intent(addServicing.this, employeeHome.class));
    }

    public void HomeButton(View view) {
        startActivity(new Intent(addServicing.this, employeeHome.class));
    }

    public void nextButton(View view) {
        startActivity(new Intent(addServicing.this, viewCustomerDetails.class));
    }

    public void reload(View view) {
        recreate();
    }
}